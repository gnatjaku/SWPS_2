# Student tasks

## Part A. Local validation
Run `python scripts/meta_bigdata_demo.py` and answer:
1. Which records pass type coercion but fail semantic validation?
2. Which record fails because of a missing field?
3. Why is email normalization useful?

## Part B. Spark validation
Run `python scripts/meta_spark_demo.py` and answer:
1. Which records fail at schema enforcement stage?
2. Which records fail only at the validation UDF stage?
3. Why is it useful to build a quality report from bad records?

## Part C. Extend the project
Add one more rule:
- either validate that email contains `@`
- or restrict countries to another chosen set
- or add a new required field, for example `segment`
