# Teacher notes

## Central message
Big Data starts not when the file is huge, but when you stop trusting the data.

## Live demo flow
1. Show the raw JSONL file and ask: which records are suspicious?
2. Run `meta_bigdata_demo.py`.
3. Explain runtime class generation from a schema.
4. Distinguish between:
   - type coercion
   - semantic validation
   - quality report
5. Run `meta_spark_demo.py`.
6. Show how Spark separates:
   - fast schema enforcement
   - optional custom validation UDF
   - split into good and bad data
   - aggregated quality report

## Questions for students
- Is type coercion enough to trust a record?
- Which errors are structural and which are semantic?
- Why is it useful to keep bad data instead of just dropping it?
- Why do we often separate schema enforcement from custom validation?

## One-line conclusion
Schema is the gate. Quality is the judgment.
