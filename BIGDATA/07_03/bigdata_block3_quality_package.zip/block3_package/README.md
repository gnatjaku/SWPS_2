# Block 3: Schema validation and data quality

This mini-project supports the teaching block:

**1:45–2:30**  
**Schema validation and data quality**  
Based on: `meta_bigdata.py` and `meta_spark.py`

## Teaching goal
Students compare two complementary approaches:
1. **Local Python metaprogramming**: create a validator class dynamically from a schema.
2. **PySpark contract enforcement**: enforce schema, flag bad records, split good/bad data, and produce a quality report.

## Files
- `data/dirty_users.jsonl` - test data with correct and incorrect records
- `scripts/meta_bigdata_demo.py` - local validator created at runtime
- `scripts/meta_spark_demo.py` - Spark schema enforcement + optional validation UDF
- `tasks/teacher_notes.md` - notes for the instructor
- `tasks/student_tasks.md` - student exercises

## Recommended run order
```bash
python scripts/meta_bigdata_demo.py
python scripts/meta_spark_demo.py
```

## Teaching storyline
1. A schema is a **contract**.
2. Type coercion is not enough: we also need **semantic validation**.
3. Quality means more than parsing: missing fields, wrong types, invalid values, and reportability.
4. In Spark, we separate:
   - fast schema enforcement
   - optional custom validation
   - output split: good / bad / report
