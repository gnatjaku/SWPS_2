from __future__ import annotations
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Tuple
import json


def create_data_processor(
    name: str,
    schema: Dict[str, type],
    *,
    coercions: Dict[str, Callable[[Any], Any]] | None = None,
    validators: Dict[str, Callable[[Any], str | None]] | None = None,
):
    coercions = coercions or {}
    validators = validators or {}

    def validate_one(self, record: Dict[str, Any]) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        for field, field_type in self.schema.items():
            if field not in record:
                raise ValueError(f"Missing field: {field}")
            v = record[field]
            try:
                if field in self.coercions:
                    v = self.coercions[field](v)
                elif not isinstance(v, field_type):
                    v = field_type(v)
            except Exception as e:
                raise TypeError(
                    f"Field '{field}' cannot be coerced to {field_type.__name__}: {v!r}"
                ) from e
            if field in self.validators:
                err = self.validators[field](v)
                if err:
                    raise ValueError(f"Field '{field}' invalid: {err}")
            out[field] = v
        return out

    def validate_batch(
        self, records: Iterable[Dict[str, Any]]
    ) -> Tuple[List[Dict[str, Any]], List[Tuple[int, Exception, Dict[str, Any]]]]:
        ok: List[Dict[str, Any]] = []
        bad: List[Tuple[int, Exception, Dict[str, Any]]] = []
        for i, r in enumerate(records):
            try:
                ok.append(self.validate_one(r))
            except Exception as e:
                bad.append((i, e, r))
        return ok, bad

    return type(
        name,
        (object,),
        {
            'schema': dict(schema),
            'coercions': dict(coercions),
            'validators': dict(validators),
            'validate_one': validate_one,
            'validate_batch': validate_batch,
        }
    )


def normalize_email(v: Any) -> str:
    if v is None:
        raise ValueError('email is null')
    return str(v).strip().lower()


def validate_age(v: int) -> str | None:
    if v < 0 or v > 120:
        return 'age out of range [0, 120]'
    return None


def validate_country(v: str) -> str | None:
    allowed = {'PL', 'DE', 'FR', 'ES', 'IT', 'CZE'}
    if v not in allowed:
        return f'country not in {sorted(allowed)}'
    return None


def load_records() -> list[dict[str, Any]]:
    root_dir = Path(__file__).resolve().parents[1]
    input_path = root_dir / 'data' / 'dirty_users.jsonl'
    rows = []
    with input_path.open('r', encoding='utf-8') as f:
        for line in f:
            rows.append(json.loads(line))
    return rows


def build_quality_report(ok: list[dict], bad: list[tuple[int, Exception, dict]]) -> None:
    print('
=== QUALITY REPORT (LOCAL) ===')
    print(f'Total records: {len(ok) + len(bad)}')
    print(f'Valid records: {len(ok)}')
    print(f'Invalid records: {len(bad)}')
    if ok or bad:
        quality = len(ok) / (len(ok) + len(bad)) * 100
        print(f'Quality score: {quality:.2f}%')

    error_buckets: dict[str, int] = {}
    for _, err, _ in bad:
        key = type(err).__name__
        error_buckets[key] = error_buckets.get(key, 0) + 1

    print('Errors by type:')
    for name, count in error_buckets.items():
        print(f'  {name}: {count}')


if __name__ == '__main__':
    UserProcessor = create_data_processor(
        'UserProcessor',
        schema={
            'user_id': int,
            'email': str,
            'age': int,
            'country': str,
        },
        coercions={
            'email': normalize_email,
        },
        validators={
            'age': validate_age,
            'country': validate_country,
        },
    )

    records = load_records()
    proc = UserProcessor()
    ok, bad = proc.validate_batch(records)

    print('=== VALID RECORDS (LOCAL) ===')
    for row in ok:
        print(row)

    print('
=== INVALID RECORDS (LOCAL) ===')
    for idx, err, row in bad:
        print(f'idx={idx} | error={err} | row={row}')

    build_quality_report(ok, bad)
