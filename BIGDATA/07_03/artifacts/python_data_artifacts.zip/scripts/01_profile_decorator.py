from __future__ import annotations

import time
from functools import wraps
from pathlib import Path

import pandas as pd


def profile_step(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        end = time.perf_counter()

        print(f"\n[PROFILE] {func.__name__}")
        print(f"  time: {end - start:.6f} s")

        if isinstance(result, pd.DataFrame):
            print(f"  shape: {result.shape}")
            print(f"  columns: {list(result.columns)}")

        return result

    return wrapper


@profile_step
def load_data(path: str | Path) -> pd.DataFrame:
    return pd.read_csv(path)


@profile_step
def high_value_orders(df: pd.DataFrame) -> pd.DataFrame:
    return df[df["amount"] > 500]


@profile_step
def sales_by_country(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df.groupby("country", as_index=False)["amount"]
        .sum()
        .sort_values("amount", ascending=False)
    )


def main() -> None:
    root_dir = Path(__file__).resolve().parents[1]
    csv_path = root_dir / "sales.csv"

    df = load_data(csv_path)
    _ = high_value_orders(df)
    summary = sales_by_country(df)

    print("\n=== TOP COUNTRIES ===")
    print(summary.head())


if __name__ == "__main__":
    main()
