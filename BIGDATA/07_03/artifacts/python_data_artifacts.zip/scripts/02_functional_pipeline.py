from __future__ import annotations

from pathlib import Path
from typing import Callable

import pandas as pd


DataStep = Callable[[pd.DataFrame], pd.DataFrame]


def pipe(df: pd.DataFrame, *steps: DataStep) -> pd.DataFrame:
    for step in steps:
        print(f"Running step: {step.__name__}")
        df = step(df)
    return df


def drop_missing_country(df: pd.DataFrame) -> pd.DataFrame:
    return df.dropna(subset=["country"])


def normalize_country(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["country"] = df["country"].astype(str).str.strip().str.upper()
    return df


def filter_positive_amount(df: pd.DataFrame) -> pd.DataFrame:
    return df[df["amount"] > 0]


def aggregate_country(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df.groupby("country", as_index=False)["amount"]
        .sum()
        .sort_values("amount", ascending=False)
    )


def main() -> None:
    root_dir = Path(__file__).resolve().parents[1]
    csv_path = root_dir / "sales.csv"
    df = pd.read_csv(csv_path)

    result = pipe(
        df,
        drop_missing_country,
        normalize_country,
        filter_positive_amount,
        aggregate_country,
    )

    print("\n=== PIPE RESULT ===")
    print(result)


if __name__ == "__main__":
    main()
