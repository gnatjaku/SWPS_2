from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterator


def read_csv_stream(path: str | Path) -> Iterator[dict]:
    with Path(path).open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            yield row


def filter_high_amount(rows: Iterator[dict], threshold: float) -> Iterator[dict]:
    for row in rows:
        try:
            amount = float(row["amount"])
            if amount > threshold:
                yield row
        except (ValueError, KeyError):
            continue


def count_by_country(rows: Iterator[dict]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for row in rows:
        country = row.get("country", "UNKNOWN")
        counts[country] = counts.get(country, 0) + 1
    return counts


def main() -> None:
    root_dir = Path(__file__).resolve().parents[1]
    csv_path = root_dir / "sales.csv"

    rows = read_csv_stream(csv_path)
    filtered = filter_high_amount(rows, threshold=500)
    result = count_by_country(filtered)

    print("=== STREAM COUNT BY COUNTRY ===")
    print(result)


if __name__ == "__main__":
    main()
