from __future__ import annotations

from pathlib import Path

import pandas as pd


class Column:
    def __init__(self, dtype: str, required: bool = True):
        self.dtype = dtype
        self.required = required
        self.name = None

    def __set_name__(self, owner, name):
        self.name = name


class DataFrameSchemaMeta(type):
    def __new__(mcls, name, bases, namespace):
        columns = {
            key: value
            for key, value in namespace.items()
            if isinstance(value, Column)
        }
        cls = super().__new__(mcls, name, bases, namespace)
        cls.__columns__ = columns
        return cls


class DataFrameSchema(metaclass=DataFrameSchemaMeta):
    __columns__ = {}

    @classmethod
    def validate(cls, df: pd.DataFrame) -> list[str]:
        errors: list[str] = []

        for col_name, col_def in cls.__columns__.items():
            if col_def.required and col_name not in df.columns:
                errors.append(f"Missing required column: {col_name}")
                continue

            if col_name in df.columns:
                actual_dtype = str(df[col_name].dtype)
                expected = col_def.dtype
                if expected not in actual_dtype:
                    errors.append(
                        f"Column {col_name}: expected {expected}, got {actual_dtype}"
                    )

        return errors


class SalesSchema(DataFrameSchema):
    order_id = Column("object")
    country = Column("object")
    amount = Column("float")
    category = Column("object")


def main() -> None:
    root_dir = Path(__file__).resolve().parents[1]
    csv_path = root_dir / "sales.csv"
    df = pd.read_csv(csv_path)

    errors = SalesSchema.validate(df)

    print("=== SCHEMA COLUMNS ===")
    print(SalesSchema.__columns__)

    print("\n=== VALIDATION RESULT ===")
    if errors:
        print("Schema errors:")
        for err in errors:
            print(" -", err)
    else:
        print("Schema OK")


if __name__ == "__main__":
    main()
