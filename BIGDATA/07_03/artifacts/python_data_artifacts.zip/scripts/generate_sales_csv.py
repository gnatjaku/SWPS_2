from __future__ import annotations

import csv
import random
from datetime import datetime, timedelta
from pathlib import Path


COUNTRIES = ["Poland", "Germany", "France", "Spain", "Italy", "Czechia"]
CATEGORIES = ["Books", "Electronics", "Clothing", "Sports", "Beauty", "Home"]


def main() -> None:
    random.seed(42)

    root_dir = Path(__file__).resolve().parents[1]
    output_path = root_dir / "sales.csv"

    start_time = datetime(2025, 1, 1, 8, 0, 0)

    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["order_id", "country", "category", "amount", "order_date"])

        for i in range(1, 1001):
            writer.writerow([
                f"ORD{i:05d}",
                random.choice(COUNTRIES),
                random.choice(CATEGORIES),
                round(random.uniform(10, 1000), 2),
                (start_time + timedelta(minutes=i)).isoformat(sep=" "),
            ])

    print(f"Generated file: {output_path}")


if __name__ == "__main__":
    main()
