from __future__ import annotations

import inspect
from pathlib import Path

import pandas as pd


ANALYSES = {}


def register_analysis(func):
    ANALYSES[func.__name__] = func
    return func


@register_analysis
def top_countries(df: pd.DataFrame) -> pd.DataFrame:
    """Top kraje według sumy sprzedaży."""
    return (
        df.groupby("country", as_index=False)["amount"]
        .sum()
        .sort_values("amount", ascending=False)
        .head(5)
    )


@register_analysis
def avg_amount_by_category(df: pd.DataFrame) -> pd.DataFrame:
    """Średnia kwota per kategoria."""
    return (
        df.groupby("category", as_index=False)["amount"]
        .mean()
        .sort_values("amount", ascending=False)
    )


def describe_registry() -> None:
    print("\n=== REGISTERED ANALYSES ===")
    for name, func in ANALYSES.items():
        print(f"\n{name}")
        print("  signature:", inspect.signature(func))
        print("  doc:", inspect.getdoc(func))


def run_analysis(name: str, df: pd.DataFrame):
    if name not in ANALYSES:
        raise ValueError(f"Unknown analysis: {name}")
    return ANALYSES[name](df)


def main() -> None:
    root_dir = Path(__file__).resolve().parents[1]
    csv_path = root_dir / "sales.csv"
    df = pd.read_csv(csv_path)

    describe_registry()

    result = run_analysis("top_countries", df)
    print("\n=== RESULT ===")
    print(result)


if __name__ == "__main__":
    main()
