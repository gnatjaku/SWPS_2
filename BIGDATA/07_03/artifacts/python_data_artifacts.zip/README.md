# Python Data Artifacts

Zestaw 5 mocnych artefaktów Pythona do analizy danych.

## Zawartość
1. `scripts/01_profile_decorator.py`
   Dekorator profilujący funkcje analityczne.

2. `scripts/02_functional_pipeline.py`
   Mini-pipeline oparty o funkcje wyższego rzędu.

3. `scripts/03_metaclass_schema.py`
   Metaklasa budująca kontrakt DataFrame.

4. `scripts/04_stream_generator.py`
   Generator do strumieniowego przetwarzania CSV.

5. `scripts/05_introspection_registry.py`
   Rejestr analiz z dekoratorem i introspekcją.

6. `scripts/generate_sales_csv.py`
   Generator danych wejściowych `sales.csv`.

## Szybki start
Najpierw wygeneruj dane:

```bash
python scripts/generate_sales_csv.py
```

Potem uruchamiaj przykłady po kolei:

```bash
python scripts/01_profile_decorator.py
python scripts/02_functional_pipeline.py
python scripts/03_metaclass_schema.py
python scripts/04_stream_generator.py
python scripts/05_introspection_registry.py
```
