from __future__ import annotations

from pathlib import Path
import pandas as pd


def main() -> None:
    root_dir = Path(__file__).resolve().parents[1]
    csv_path = root_dir / "data" / "transactions.csv"

    df = pd.read_csv(csv_path)

    print("\n=== PANDAS ===")
    print("Podgląd danych:")
    print(df.head())

    print("\n1. Liczba rekordów:")
    print(len(df))

    print("\n2. Średnia amount:")
    print(round(df["amount"].mean(), 2))

    print("\n3. Suma sprzedaży per kraj:")
    print(df.groupby("country")["amount"].sum().sort_values(ascending=False))

    print("\n4. Suma sprzedaży per kategoria:")
    print(df.groupby("category")["amount"].sum().sort_values(ascending=False))

    print("\n5. Top 3 kraje:")
    print(df.groupby("country")["amount"].sum().sort_values(ascending=False).head(3))

    print("\n6. Liczba transakcji per metoda płatności:")
    print(df.groupby("payment_method")["transaction_id"].count().sort_values(ascending=False))

    print("\n7. Transakcje > 400:")
    print((df["amount"] > 400).sum())

    print("\nKomentarz:")
    print("Pandas działa natychmiastowo i świetnie nadaje się do analizy lokalnej oraz eksploracji danych.")


if __name__ == "__main__":
    main()
