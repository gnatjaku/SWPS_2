from __future__ import annotations

from pathlib import Path
import dask.dataframe as dd


def main() -> None:
    root_dir = Path(__file__).resolve().parents[1]
    csv_path = root_dir / "data" / "transactions.csv"

    ddf = dd.read_csv(csv_path)

    print("\n=== DASK ===")
    print("Podgląd danych:")
    print(ddf.head())

    print("\n1. Liczba rekordów:")
    print(ddf.shape[0].compute())

    print("\n2. Średnia amount:")
    print(round(ddf["amount"].mean().compute(), 2))

    print("\n3. Suma sprzedaży per kraj:")
    print(ddf.groupby("country")["amount"].sum().compute().sort_values(ascending=False))

    print("\n4. Suma sprzedaży per kategoria:")
    print(ddf.groupby("category")["amount"].sum().compute().sort_values(ascending=False))

    print("\n5. Top 3 kraje:")
    print(ddf.groupby("country")["amount"].sum().compute().sort_values(ascending=False).head(3))

    print("\n6. Liczba transakcji per metoda płatności:")
    print(
        ddf.groupby("payment_method")["transaction_id"]
        .count()
        .compute()
        .sort_values(ascending=False)
    )

    print("\n7. Transakcje > 400:")
    print((ddf[ddf["amount"] > 400].shape[0]).compute())

    print("\nKomentarz:")
    print("Dask zachowuje styl podobny do pandas, ale wiele operacji wykonuje leniwie. Wyniki materializujemy przez .compute().")


if __name__ == "__main__":
    main()
