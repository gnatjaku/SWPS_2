from __future__ import annotations

from pathlib import Path
import csv
import random
from datetime import datetime, timedelta

COUNTRIES = ["Poland", "Germany", "France", "Spain", "Italy", "Czechia"]
CATEGORIES = ["Books", "Electronics", "Clothing", "Sports", "Beauty", "Home"]
PAYMENTS = ["card", "blik", "transfer", "cash"]


def main() -> None:
    root_dir = Path(__file__).resolve().parents[1]
    data_dir = root_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    output_path = data_dir / "transactions.csv"

    random.seed(42)
    start = datetime(2025, 1, 1, 8, 0, 0)

    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(
            [
                "transaction_id",
                "customer_id",
                "country",
                "category",
                "amount",
                "payment_method",
                "event_time",
            ]
        )

        for i in range(1, 50001):
            transaction_id = f"TX{i:06d}"
            customer_id = f"C{random.randint(1, 6000):05d}"
            country = random.choice(COUNTRIES)
            category = random.choice(CATEGORIES)
            amount = round(random.uniform(20, 800), 2)
            payment_method = random.choice(PAYMENTS)
            event_time = start + timedelta(minutes=i)

            writer.writerow(
                [
                    transaction_id,
                    customer_id,
                    country,
                    category,
                    amount,
                    payment_method,
                    event_time.isoformat(sep=" "),
                ]
            )

    print(f"Wygenerowano dane: {output_path}")


if __name__ == "__main__":
    main()
