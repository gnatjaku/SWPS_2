from __future__ import annotations

from pathlib import Path
from pyspark.sql import SparkSession
from pyspark.sql.functions import avg, count, desc, sum as spark_sum


def main() -> None:
    root_dir = Path(__file__).resolve().parents[1]
    csv_path = root_dir / "data" / "transactions.csv"

    spark = (
        SparkSession.builder.appName("BigDataBlock2Spark")
        .master("local[*]")
        .getOrCreate()
    )

    df = spark.read.csv(str(csv_path), header=True, inferSchema=True)

    print("\n=== SPARK ===")
    print("Schemat danych:")
    df.printSchema()

    print("\nPodgląd danych:")
    df.show(5, truncate=False)

    print("\n1. Liczba rekordów:")
    print(df.count())

    print("\n2. Średnia amount:")
    df.select(avg("amount").alias("avg_amount")).show()

    print("\n3. Suma sprzedaży per kraj:")
    df.groupBy("country").agg(spark_sum("amount").alias("total_sales")).orderBy(desc("total_sales")).show(truncate=False)

    print("\n4. Suma sprzedaży per kategoria:")
    df.groupBy("category").agg(spark_sum("amount").alias("total_sales")).orderBy(desc("total_sales")).show(truncate=False)

    print("\n5. Top 3 kraje:")
    df.groupBy("country").agg(spark_sum("amount").alias("total_sales")).orderBy(desc("total_sales")).show(3, truncate=False)

    print("\n6. Liczba transakcji per metoda płatności:")
    df.groupBy("payment_method").agg(count("transaction_id").alias("transactions")).orderBy(desc("transactions")).show(truncate=False)

    print("\n7. Transakcje > 400:")
    print(df.filter(df.amount > 400).count())

    print("\nKomentarz:")
    print("Spark wnosi rozproszony model wykonania, większy narzut startowy i styl pracy bliższy SQL oraz planowi wykonania.")

    spark.stop()


if __name__ == "__main__":
    main()
