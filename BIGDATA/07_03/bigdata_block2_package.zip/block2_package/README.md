# Blok 2: Jedno zadanie analityczne w pandas, Dask i Spark

## Cel dydaktyczny
W tym bloku realizujemy **to samo zadanie analityczne** trzema narzędziami:
- pandas
- Dask
- PySpark

Chodzi nie tylko o kod, ale o porównanie:
- składni
- modelu wykonania
- kosztu uruchomienia
- sensownych zastosowań

## Wspólne zadanie
Dane transakcyjne znajdują się w pliku `data/transactions.csv` i zawierają kolumny:
- `transaction_id`
- `customer_id`
- `country`
- `category`
- `amount`
- `payment_method`
- `event_time`

### Pytania analityczne
1. Ile jest rekordów?
2. Jaka jest średnia wartość `amount`?
3. Jaka jest suma sprzedaży dla każdego kraju?
4. Jaka jest suma sprzedaży dla każdej kategorii?
5. Jakie są 3 kraje o najwyższej sprzedaży?
6. Jaka jest liczba transakcji dla każdej metody płatności?
7. Ile transakcji ma kwotę większą niż 400?

## Kolejność na zajęciach
1. `python scripts/generate_transactions.py`
2. `python scripts/pandas_solution.py`
3. `python scripts/dask_solution.py`
4. `python scripts/spark_solution.py`

## Pytania do dyskusji
- Dlaczego pandas jest najwygodniejszy na start?
- Co zmienia `.compute()` w Dask?
- Dlaczego Spark ma większy narzut startowy?
- Czy dla 50 tys. rekordów Spark ma sens?
- W którym miejscu kończy się wygoda, a zaczyna potrzeba skali?

## Zadania dla studentów
Materiały znajdują się w folderze `tasks/`.
