# Notatki dla prowadzącego

## Główna myśl bloku
To samo zadanie analityczne może mieć niemal tę samą logikę biznesową, ale zupełnie inny model wykonania.

## Co podkreślać
- pandas: najprostszy start, pełna wygoda, dane lokalne
- Dask: znajoma składnia, ale lazy execution i .compute()
- Spark: większy narzut, rozproszony silnik, styl SQL-owy

## Dobre pytania do sali
- Czy Dask to tylko większy pandas?
- Czy Spark ma sens dla małego pliku?
- Co jest kosztem prostoty, a co kosztem skali?
- W którym narzędziu najłatwiej debugować?

## Finał dyskusji
Nie pytamy tylko „jak działa biblioteka”. Pytamy: jaki model przetwarzania jest adekwatny do problemu?
