# Zadania dla studentów

## Część A. Porównanie narzędzi
Po uruchomieniu trzech skryptów odpowiedz:
1. Który kod jest najbardziej czytelny?
2. W którym miejscu Dask różni się od pandas?
3. Dlaczego Spark ma największy narzut wejścia?
4. Które narzędzie wybrałbyś do 100 MB danych, a które do 100 GB?

## Część B. Rozszerz analizę
Zmodyfikuj każdy z trzech skryptów tak, aby dodatkowo policzyć:
1. średnią wartość transakcji dla każdej kategorii,
2. top 5 klientów pod względem sumy wydatków,
3. liczbę transakcji dla każdego kraju i kategorii razem.

## Część C. Wniosek
Napisz 8-10 zdań:
- czym różni się składnia,
- czym różni się model wykonania,
- kiedy narzędzie jest sensowne, a kiedy jest przesadą.
