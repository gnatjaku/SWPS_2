# Big Data Block 1 Package

Pakiet do zajęć: **Mapa narzędzi i paradygmatów**

Zawartość:
- `scripts/generate_sales_data.py` - generator danych do analizy batch
- `scripts/pandas_demo.py` - analiza w pandas
- `scripts/dask_demo.py` - analiza w Dask
- `scripts/spark_batch_demo.py` - analiza batch w PySpark
- `scripts/generate_streaming_files.py` - generator plików do streamingu
- `scripts/spark_streaming_demo.py` - demo Structured Streaming w PySpark
- `data/sales.csv` - przykładowe dane wsadowe
- `stream_input/` - katalog obserwowany przez streaming
- `requirements.txt` - biblioteki do instalacji

## Cel dydaktyczny
Na tym samym problemie pokazujemy 4 sposoby pracy z danymi:
1. pandas
2. Dask
3. Spark batch
4. Spark streaming

## Problem wspólny
Mamy dane sprzedażowe z kolumnami:
- `order_id`
- `country`
- `category`
- `amount`
- `order_date`

Pytania:
1. Ile mamy rekordów?
2. Jaka jest średnia wartość zamówienia?
3. Jaka jest suma sprzedaży dla każdego kraju?
4. Który kraj wygenerował największy przychód?

## Instalacja
```bash
pip install -r requirements.txt
```

Jeśli Spark nie jest dostępny lokalnie, możesz użyć środowiska z gotowym PySpark albo pominąć część streamingową i batchową.

## Kolejność uruchamiania

### 1. Generator danych
```bash
python scripts/generate_sales_data.py
```

### 2. Pandas
```bash
python scripts/pandas_demo.py
```

### 3. Dask
```bash
python scripts/dask_demo.py
```

### 4. Spark batch
```bash
python scripts/spark_batch_demo.py
```

### 5. Streaming
Najpierw uruchom terminal nr 1:
```bash
python scripts/spark_streaming_demo.py
```

Potem w terminalu nr 2 generuj kolejne pliki:
```bash
python scripts/generate_streaming_files.py
```

## Jak tłumaczyć studentom
- **pandas**: wygodny start, świetny do eksploracji, działa lokalnie w RAM
- **Dask**: podobny styl do pandas, ale lazy execution i partycje
- **Spark**: przetwarzanie rozproszone, deklaratywny styl, większa skala
- **Streaming**: dane nie czekają w pliku, tylko napływają w czasie

## Pytania do studentów
1. Czy Dask to tylko większy pandas?
2. Czy Spark ma sens dla małego pliku CSV?
3. Co zmienia `.compute()`?
4. Dlaczego w streamingu chcemy znać schemat danych z góry?
5. Kiedy batch nie wystarcza?
