"""Generator danych sprzedażowych do demonstracji pandas, Dask i Spark.

Tworzy plik CSV z przykładowymi danymi wsadowymi.
"""

from __future__ import annotations

import csv
import random
from datetime import datetime, timedelta
from pathlib import Path


COUNTRIES = ["Poland", "Germany", "France", "Spain", "Italy", "Czechia"]
CATEGORIES = ["Books", "Electronics", "Clothing", "Sports", "Beauty"]


def random_date(start: datetime, end: datetime) -> datetime:
    """Zwraca losową datę z przedziału <start, end>."""
    delta = end - start
    random_seconds = random.randint(0, int(delta.total_seconds()))
    return start + timedelta(seconds=random_seconds)


def main() -> None:
    """Generuje plik sales.csv z przykładowymi danymi."""
    random.seed(42)

    root_dir = Path(__file__).resolve().parents[1]
    output_path = root_dir / "data" / "sales.csv"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    start = datetime(2025, 1, 1)
    end = datetime(2025, 3, 31)

    with output_path.open("w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["order_id", "country", "category", "amount", "order_date"])

        for order_no in range(1, 1001):
            order_id = f"ORD-{order_no:05d}"
            country = random.choice(COUNTRIES)
            category = random.choice(CATEGORIES)
            amount = round(random.uniform(20.0, 1500.0), 2)
            order_date = random_date(start, end).strftime("%Y-%m-%d %H:%M:%S")

            writer.writerow([order_id, country, category, amount, order_date])

    print(f"Generated: {output_path}")


if __name__ == "__main__":
    main()
