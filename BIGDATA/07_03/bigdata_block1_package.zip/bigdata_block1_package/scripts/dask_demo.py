"""Analiza danych sprzedażowych w Dask krok po kroku."""

from __future__ import annotations

from pathlib import Path

import dask.dataframe as dd


def main() -> None:
    """Uruchamia analizę wsadową w Dask."""
    root_dir = Path(__file__).resolve().parents[1]
    csv_path = root_dir / "data" / "sales.csv"

    ddf = dd.read_csv(csv_path)

    print("\n=== DASK DEMO ===")
    print("\n1. Podgląd danych:")
    print(ddf.head())

    print("\n2. Liczba rekordów:")
    print(ddf.shape[0].compute())

    print("\n3. Średnia wartość zamówienia:")
    print(round(ddf["amount"].mean().compute(), 2))

    print("\n4. Suma sprzedaży per kraj:")
    sales_by_country = (
        ddf.groupby("country")["amount"]
        .sum()
        .compute()
        .sort_values(ascending=False)
    )
    print(sales_by_country)

    print("\n5. Kraj z największą sprzedażą:")
    top_country = sales_by_country.idxmax()
    top_value = sales_by_country.max()
    print(f"{top_country}: {top_value:.2f}")

    print("\n6. Komentarz dydaktyczny:")
    print("W Dask wiele operacji jest leniwych. Wynik materializujemy dopiero przez .compute().")


if __name__ == "__main__":
    main()
