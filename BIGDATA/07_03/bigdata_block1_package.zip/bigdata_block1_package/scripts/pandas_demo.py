"""Analiza danych sprzedażowych w pandas krok po kroku."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


def main() -> None:
    """Uruchamia analizę wsadową w pandas."""
    root_dir = Path(__file__).resolve().parents[1]
    csv_path = root_dir / "data" / "sales.csv"

    df = pd.read_csv(csv_path)

    print("\n=== PANDAS DEMO ===")
    print("\n1. Podgląd danych:")
    print(df.head())

    print("\n2. Liczba rekordów:")
    print(len(df))

    print("\n3. Średnia wartość zamówienia:")
    print(round(df["amount"].mean(), 2))

    print("\n4. Suma sprzedaży per kraj:")
    sales_by_country = df.groupby("country")["amount"].sum().sort_values(ascending=False)
    print(sales_by_country)

    print("\n5. Kraj z największą sprzedażą:")
    top_country = sales_by_country.idxmax()
    top_value = sales_by_country.max()
    print(f"{top_country}: {top_value:.2f}")


if __name__ == "__main__":
    main()
