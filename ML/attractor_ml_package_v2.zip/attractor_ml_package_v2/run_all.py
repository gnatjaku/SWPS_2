from solution_1_pca_classifier_v2 import main as run_solution_1
from solution_2_resonant_attractor_v2 import main as run_solution_2
from solution_3_hybrid_decision_engine_v2 import main as run_solution_3


if __name__ == "__main__":
    run_solution_1()
    print("\n" + "#" * 72 + "\n")
    run_solution_2()
    print("\n" + "#" * 72 + "\n")
    run_solution_3()
