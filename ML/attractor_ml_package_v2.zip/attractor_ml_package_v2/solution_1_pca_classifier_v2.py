"""Solution 1 v2: Classical PCA + two scikit-learn classifiers + PCA plot."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from shared_dataset import FEATURE_NAMES, generate_projects


OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


def build_models() -> dict[str, Pipeline]:
    return {
        "logistic_regression": Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                ("pca", PCA(n_components=2, random_state=42)),
                ("classifier", LogisticRegression(max_iter=1000, random_state=42)),
            ]
        ),
        "random_forest": Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                ("pca", PCA(n_components=2, random_state=42)),
                (
                    "classifier",
                    RandomForestClassifier(
                        n_estimators=250,
                        max_depth=5,
                        min_samples_leaf=3,
                        random_state=42,
                    ),
                ),
            ]
        ),
    }


def save_pca_plot(df_plot: pd.DataFrame, path: Path) -> None:
    plt.figure(figsize=(8, 6))
    good = df_plot[df_plot["true_label"] == 1]
    weak = df_plot[df_plot["true_label"] == 0]
    plt.scatter(weak["pc1"], weak["pc2"], alpha=0.7, label="class 0")
    plt.scatter(good["pc1"], good["pc2"], alpha=0.7, label="class 1")
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.title("PCA projection of AI project ideas")
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=160)
    plt.close()


def main() -> None:
    dataset = generate_projects(n_samples=160, seed=42)
    df = dataset.frame

    X = df[FEATURE_NAMES]
    y = df["class_label"]

    X_train, X_test, y_train, y_test, train_index, test_index = train_test_split(
        X,
        y,
        df.index,
        test_size=0.25,
        random_state=42,
        stratify=y,
    )

    print("=" * 72)
    print("SOLUTION 1 v2 | PCA + LOGISTIC REGRESSION + RANDOM FOREST")
    print("=" * 72)

    all_predictions = []
    metric_rows = []
    plot_frame = None

    for model_name, pipeline in build_models().items():
        pipeline.fit(X_train, y_train)
        y_pred = pipeline.predict(X_test)
        y_proba = pipeline.predict_proba(X_test)[:, 1]
        auc = roc_auc_score(y_test, y_proba)

        print(f"\n--- {model_name.upper()} ---")
        pca_model: PCA = pipeline.named_steps["pca"]
        print("Explained variance ratio:")
        for i, ratio in enumerate(pca_model.explained_variance_ratio_, start=1):
            print(f"PC{i}: {ratio:.4f}")
        print("Confusion matrix:")
        print(confusion_matrix(y_test, y_pred))
        print("Classification report:")
        print(classification_report(y_test, y_pred, digits=4))
        print(f"ROC AUC: {auc:.4f}")

        transformed_test = pipeline.named_steps["pca"].transform(
            pipeline.named_steps["scaler"].transform(X_test)
        )

        result_df = pd.DataFrame(
            {
                "project_name": df.loc[test_index, "project_name"].values,
                "true_label": y_test.values,
                "predicted_label": y_pred,
                "predicted_probability": y_proba,
                "pc1": transformed_test[:, 0],
                "pc2": transformed_test[:, 1],
                "model": model_name,
            }
        ).sort_values(by="predicted_probability", ascending=False)

        all_predictions.append(result_df)
        metric_rows.append(
            {
                "model": model_name,
                "roc_auc": auc,
                "accuracy": float((y_pred == y_test).mean()),
                "positive_rate_predicted": float(y_pred.mean()),
            }
        )

        if model_name == "logistic_regression":
            plot_frame = result_df.copy()

    predictions_df = pd.concat(all_predictions, ignore_index=True)
    metrics_df = pd.DataFrame(metric_rows).sort_values(by="roc_auc", ascending=False)

    predictions_csv = OUTPUT_DIR / "solution_1_v2_predictions.csv"
    metrics_csv = OUTPUT_DIR / "solution_1_v2_metrics.csv"
    plot_png = OUTPUT_DIR / "solution_1_v2_pca_plot.png"

    predictions_df.to_csv(predictions_csv, index=False)
    metrics_df.to_csv(metrics_csv, index=False)
    if plot_frame is not None:
        save_pca_plot(plot_frame, plot_png)

    print(f"\nSaved predictions to: {predictions_csv}")
    print(f"Saved metrics to: {metrics_csv}")
    print(f"Saved PCA plot to: {plot_png}")
    print("\nModel comparison:")
    print(metrics_df.to_string(index=False))


if __name__ == "__main__":
    main()
