# PCA + klasyfikatory ML + rozwinięty atraktor + hybryda decyzji v2

To jest wersja 2.0 paczki. Pokazuje trzy poziomy pracy z tym samym zbiorem danych projektów AI.

## Co nowego względem v1

- wykres PCA zapisany do PNG,
- dwa klasyfikatory ze scikit-learn: `LogisticRegression` i `RandomForestClassifier`,
- tabela porównawcza metryk modeli,
- rozwinięty atraktor z dynamiczną aktualizacją i plikiem wyjaśnień cech,
- hybryda `ML probability + attractor resonance`,
- mapa decyzji hybrydowej w formie wykresu PNG.

## Struktura

- `shared_dataset.py`  
  Generowanie wspólnego zbioru danych z pięcioma cechami.

- `solution_1_pca_classifier_v2.py`  
  Klasyczny pipeline ML z PCA, logistyką, Random Forest i wykresem PCA.

- `solution_2_resonant_attractor_v2.py`  
  Rozwinięty atraktor: ważona odległość, rezonans, ranking, explainability, dynamiczna aktualizacja wzorca.

- `solution_3_hybrid_decision_engine_v2.py`  
  Silnik hybrydowy łączący prawdopodobieństwo ML z rezonansem atraktora.

- `run_all.py`  
  Uruchamia wszystkie trzy rozwiązania.

## Instalacja

```bash
pip install -r requirements.txt
```

## Uruchomienie

```bash
python run_all.py
```

Możesz też uruchamiać każdy skrypt osobno.

## Wyniki

W katalogu `outputs/` pojawią się między innymi:

- `solution_1_v2_predictions.csv`
- `solution_1_v2_metrics.csv`
- `solution_1_v2_pca_plot.png`
- `solution_2_v2_static_ranking.csv`
- `solution_2_v2_dynamic_ranking.csv`
- `solution_2_v2_comparison.csv`
- `solution_2_v2_best_project_explanation.csv`
- `solution_3_v2_hybrid_scores.csv`
- `solution_3_v2_ml_metrics.csv`
- `solution_3_v2_hybrid_plot.png`
- `solution_3_v2_top10.csv`

## Sens dydaktyczny

### 1. Klasyczny ML
Tu odpowiadasz na pytanie: **czy projekt wygląda jak członek klasy projektów dobrych?**

### 2. Atraktor
Tu odpowiadasz na pytanie: **jak blisko projekt leży wzorca, którego naprawdę szukasz?**

### 3. Hybryda
Tu odpowiadasz na pytanie: **czy projekt jest jednocześnie statystycznie obiecujący i semantycznie zgodny z kierunkiem?**

To daje bardzo ładny kontrast między klasycznym uczeniem maszynowym, selekcją przez podobieństwo i decyzją warstwową.
