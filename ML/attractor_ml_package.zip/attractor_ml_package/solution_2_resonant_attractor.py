"""Solution 2: Expanded attractor-based reasoning.

This script extends the earlier attractor idea into a more AI-flavored decision
engine:
1. Weighted distance
2. Resonance score
3. Dynamic attractor update from top-k projects
4. Comparison between static and updated attractor
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from shared_dataset import FEATURE_NAMES, IDEAL_VECTOR, generate_projects


OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


@dataclass
class ResonantAttractor:
    """Weighted attractor used for project selection."""

    target_vector: np.ndarray
    feature_names: list[str]
    weights: np.ndarray

    def weighted_distance(self, vector: np.ndarray) -> float:
        diff = vector - self.target_vector
        return float(np.sqrt(np.sum(self.weights * np.square(diff))))

    def resonance(self, vector: np.ndarray) -> float:
        return 1.0 / (1.0 + self.weighted_distance(vector))

    def explain(self, vector: np.ndarray) -> dict[str, float]:
        contributions = self.weights * np.square(vector - self.target_vector)
        return {
            name: float(value)
            for name, value in zip(self.feature_names, contributions)
        }

    def rank(self, frame: pd.DataFrame, top_k: int | None = None) -> pd.DataFrame:
        ranked = frame.copy()
        ranked["resonance"] = ranked[self.feature_names].apply(
            lambda row: self.resonance(row.to_numpy(dtype=float)),
            axis=1,
        )
        ranked["weighted_distance"] = ranked[self.feature_names].apply(
            lambda row: self.weighted_distance(row.to_numpy(dtype=float)),
            axis=1,
        )
        ranked = ranked.sort_values(by="resonance", ascending=False)
        if top_k is not None:
            ranked = ranked.head(top_k)
        return ranked

    def update_from_top_k(self, frame: pd.DataFrame, top_k: int = 5, alpha: float = 0.60) -> np.ndarray:
        ranked = self.rank(frame, top_k=top_k)
        mean_top = ranked[self.feature_names].mean().to_numpy(dtype=float)
        updated = alpha * self.target_vector + (1.0 - alpha) * mean_top
        self.target_vector = updated
        return updated


def print_vector(title: str, vector: np.ndarray) -> None:
    print(f"\n{title}")
    for name, value in zip(FEATURE_NAMES, vector):
        print(f"  {name:18s}: {value:.4f}")


def main() -> None:
    dataset = generate_projects(n_samples=120, seed=42)
    df = dataset.frame

    weights = np.array([1.25, 1.00, 1.10, 1.50, 1.40], dtype=float)
    attractor = ResonantAttractor(
        target_vector=IDEAL_VECTOR.copy(),
        feature_names=FEATURE_NAMES.copy(),
        weights=weights,
    )

    print("=" * 70)
    print("SOLUTION 2 | EXPANDED RESONANT ATTRACTOR")
    print("=" * 70)

    print_vector("Initial attractor vector:", attractor.target_vector)
    print("\nWeights:")
    for name, weight in zip(FEATURE_NAMES, weights):
        print(f"  {name:18s}: {weight:.2f}")

    ranked_static = attractor.rank(df)
    print("\nTop 10 projects under the static attractor:")
    print(
        ranked_static[
            ["project_name", "class_label", "resonance", "weighted_distance"]
        ]
        .head(10)
        .to_string(index=False)
    )

    top_project = ranked_static.iloc[0]
    explanation = attractor.explain(top_project[FEATURE_NAMES].to_numpy(dtype=float))
    print(f"\nContribution breakdown for best project: {top_project['project_name']}")
    for name, contribution in explanation.items():
        print(f"  {name:18s}: {contribution:.6f}")

    updated_vector = attractor.update_from_top_k(df, top_k=5, alpha=0.60)
    print_vector("Updated attractor vector after learning from top-5 projects:", updated_vector)

    ranked_dynamic = attractor.rank(df)
    comparison = ranked_dynamic[["project_name", "resonance"]].rename(
        columns={"resonance": "dynamic_resonance"}
    ).merge(
        ranked_static[["project_name", "resonance"]].rename(
            columns={"resonance": "static_resonance"}
        ),
        on="project_name",
        how="left",
    )
    comparison["resonance_shift"] = (
        comparison["dynamic_resonance"] - comparison["static_resonance"]
    )
    comparison = comparison.sort_values(by="dynamic_resonance", ascending=False)

    static_csv = OUTPUT_DIR / "solution_2_static_ranking.csv"
    dynamic_csv = OUTPUT_DIR / "solution_2_dynamic_ranking.csv"
    comparison_csv = OUTPUT_DIR / "solution_2_comparison.csv"

    ranked_static.to_csv(static_csv, index=False)
    ranked_dynamic.to_csv(dynamic_csv, index=False)
    comparison.to_csv(comparison_csv, index=False)

    print(f"\nSaved static ranking to: {static_csv}")
    print(f"Saved dynamic ranking to: {dynamic_csv}")
    print(f"Saved comparison to: {comparison_csv}")

    print("\nTop 10 projects after dynamic attractor update:")
    print(
        ranked_dynamic[
            ["project_name", "class_label", "resonance", "weighted_distance"]
        ]
        .head(10)
        .to_string(index=False)
    )


if __name__ == "__main__":
    main()
