"""Solution 1: Classical PCA + scikit-learn classifier.

This script shows a standard ML pipeline:
1. Generate synthetic data.
2. Split into train / test.
3. Standardize features.
4. Reduce dimensions with PCA.
5. Train a classifier.
6. Print metrics and most important observations.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from shared_dataset import FEATURE_NAMES, generate_projects


OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


def main() -> None:
    dataset = generate_projects(n_samples=120, seed=42)
    df = dataset.frame

    X = df[FEATURE_NAMES]
    y = df["class_label"]

    X_train, X_test, y_train, y_test, train_index, test_index = train_test_split(
        X,
        y,
        df.index,
        test_size=0.25,
        random_state=42,
        stratify=y,
    )

    pipeline = Pipeline(
        steps=[
            ("scaler", StandardScaler()),
            ("pca", PCA(n_components=2, random_state=42)),
            ("classifier", LogisticRegression(max_iter=1000, random_state=42)),
        ]
    )

    pipeline.fit(X_train, y_train)
    y_pred = pipeline.predict(X_test)
    y_proba = pipeline.predict_proba(X_test)[:, 1]

    print("=" * 70)
    print("SOLUTION 1 | PCA + LOGISTIC REGRESSION")
    print("=" * 70)
    print("\nExplained variance ratio of PCA components:")
    pca_model: PCA = pipeline.named_steps["pca"]
    for i, ratio in enumerate(pca_model.explained_variance_ratio_, start=1):
        print(f"PC{i}: {ratio:.4f}")

    print("\nConfusion matrix:")
    print(confusion_matrix(y_test, y_pred))

    print("\nClassification report:")
    print(classification_report(y_test, y_pred, digits=4))

    transformed_test = pipeline.named_steps["pca"].transform(
        pipeline.named_steps["scaler"].transform(X_test)
    )

    result_df = pd.DataFrame(
        {
            "project_name": df.loc[test_index, "project_name"].values,
            "true_label": y_test.values,
            "predicted_label": y_pred,
            "predicted_probability": y_proba,
            "pc1": transformed_test[:, 0],
            "pc2": transformed_test[:, 1],
        }
    ).sort_values(by="predicted_probability", ascending=False)

    csv_path = OUTPUT_DIR / "solution_1_predictions.csv"
    result_df.to_csv(csv_path, index=False)
    print(f"\nSaved prediction table to: {csv_path}")

    print("\nTop 10 projects with highest predicted probability of success:")
    print(result_df.head(10).to_string(index=False))


if __name__ == "__main__":
    main()
