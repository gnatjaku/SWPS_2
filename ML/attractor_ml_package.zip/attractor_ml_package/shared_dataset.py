"""Shared synthetic dataset for PCA/classifier and attractor-based selection.

The dataset simulates AI project ideas evaluated on five dimensions:
- novelty
- feasibility
- business
- vision_alignment
- depth

Two labels are generated:
- class_label: 1 for strong / recommended projects, 0 otherwise
- names for interpretability
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

import numpy as np
import pandas as pd


FEATURE_NAMES = [
    "novelty",
    "feasibility",
    "business",
    "vision_alignment",
    "depth",
]


@dataclass(frozen=True)
class ProjectDataset:
    """Container for project data used by both approaches."""

    frame: pd.DataFrame
    feature_names: List[str]


PROJECT_NAME_PREFIXES = [
    "Synapse",
    "Aether",
    "Resonance",
    "Helix",
    "Orion",
    "Atlas",
    "Cortex",
    "Nova",
    "Sigma",
    "Quantum",
    "Vector",
    "Lattice",
]

PROJECT_NAME_SUFFIXES = [
    "Engine",
    "Layer",
    "Prototype",
    "Studio",
    "Fabric",
    "Signal",
    "Navigator",
    "Matrix",
    "Pulse",
    "Bridge",
]


IDEAL_VECTOR = np.array([0.90, 0.76, 0.84, 0.97, 0.94], dtype=float)


def _build_names(n_samples: int) -> List[str]:
    names: List[str] = []
    for i in range(n_samples):
        prefix = PROJECT_NAME_PREFIXES[i % len(PROJECT_NAME_PREFIXES)]
        suffix = PROJECT_NAME_SUFFIXES[(i * 3) % len(PROJECT_NAME_SUFFIXES)]
        names.append(f"{prefix} {suffix} {i + 1:02d}")
    return names


def generate_projects(n_samples: int = 120, seed: int = 42) -> ProjectDataset:
    """Generate a reproducible dataset of project ideas.

    Projects are sampled around a few latent centers so PCA has something
    meaningful to separate. Labels are created from a mixture of closeness to
    the ideal vector and explicit business / feasibility thresholds.
    """

    rng = np.random.default_rng(seed)

    centers = np.array(
        [
            [0.88, 0.78, 0.82, 0.95, 0.91],
            [0.55, 0.92, 0.74, 0.48, 0.42],
            [0.94, 0.52, 0.91, 0.99, 0.98],
            [0.30, 0.65, 0.44, 0.26, 0.28],
        ]
    )
    center_probs = np.array([0.35, 0.25, 0.20, 0.20])

    rows = []
    names = _build_names(n_samples)
    for i in range(n_samples):
        center = centers[rng.choice(len(centers), p=center_probs)]
        noise = rng.normal(loc=0.0, scale=0.08, size=len(FEATURE_NAMES))
        vector = np.clip(center + noise, 0.0, 1.0)

        distance_to_ideal = float(np.linalg.norm(vector - IDEAL_VECTOR))
        quality_score = 1.0 / (1.0 + distance_to_ideal)

        class_label = int(
            quality_score > 0.68
            and vector[1] > 0.55
            and vector[2] > 0.60
            and vector[3] > 0.60
        )

        rows.append(
            {
                "project_name": names[i],
                **{feature: float(value) for feature, value in zip(FEATURE_NAMES, vector)},
                "quality_score": quality_score,
                "class_label": class_label,
            }
        )

    frame = pd.DataFrame(rows)
    return ProjectDataset(frame=frame, feature_names=FEATURE_NAMES.copy())


if __name__ == "__main__":
    dataset = generate_projects()
    print(dataset.frame.head())
    print("\nLabel distribution:")
    print(dataset.frame["class_label"].value_counts())
