"""Convenience launcher for both solutions."""

from solution_1_pca_classifier import main as pca_main
from solution_2_resonant_attractor import main as attractor_main


if __name__ == "__main__":
    pca_main()
    print("\n" + "#" * 70 + "\n")
    attractor_main()
