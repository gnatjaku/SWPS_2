# PCA + klasyfikator ML oraz rozwinięty atraktor rezonansowy

Ten pakiet zawiera dwa niezależne, ale spójne rozwiązania zbudowane na wspólnym zbiorze danych o projektach AI.

## Struktura

- `shared_dataset.py`  
  Generowanie wspólnego zbioru danych z pięcioma cechami: `novelty`, `feasibility`, `business`, `vision_alignment`, `depth`.

- `solution_1_pca_classifier.py`  
  Klasyczny pipeline ML:
  1. standaryzacja danych,
  2. PCA do 2 składowych,
  3. klasyfikator `LogisticRegression` ze scikit-learn,
  4. raport jakości i tabela predykcji.

- `solution_2_resonant_attractor.py`  
  Rozbudowa przykładu z atraktorem:
  1. ważona odległość od wzorca,
  2. score rezonansu,
  3. ranking projektów,
  4. wyjaśnienie wkładu poszczególnych cech,
  5. dynamiczna aktualizacja atraktora na podstawie top-k rekordów.

- `run_all.py`  
  Uruchamia oba rozwiązania po kolei.

## Jak uruchomić

```bash
pip install -r requirements.txt
python run_all.py
```

Możesz też uruchamiać skrypty osobno:

```bash
python solution_1_pca_classifier.py
python solution_2_resonant_attractor.py
```

## Co dostaniesz po uruchomieniu

W katalogu `outputs/` pojawią się pliki CSV:

- `solution_1_predictions.csv`
- `solution_2_static_ranking.csv`
- `solution_2_dynamic_ranking.csv`
- `solution_2_comparison.csv`

## Sens dydaktyczny

### Rozwiązanie 1
To klasyczne podejście ML. Dane przechodzą przez pipeline, PCA redukuje wymiar, a klasyfikator przewiduje klasę projektu.

### Rozwiązanie 2
To podejście bardziej koncepcyjne i "Twoje": system nie uczy się klasy bezpośrednio, tylko ocenia zgodność projektu z atraktorem jakości. Potem atraktor może się delikatnie przesuwać pod wpływem najlepszych przykładów.

## Różnica filozoficzna

- PCA + klasyfikator odpowiada na pytanie: **czy ten projekt należy do klasy dobrych projektów?**
- Atraktor odpowiada na pytanie: **jak mocno ten projekt rezonuje z wzorcem, którego naprawdę szukamy?**

To właśnie daje fajny kontrast między klasycznym ML a bardziej semantyczno-decyzyjnym mechanizmem wyboru.
