from solution_1_rf_mlp_v3 import main as solution1_main
from solution_2_resonant_attractor_v3 import main as solution2_main
from solution_3_hybrid_emergence_v3 import main as solution3_main


if __name__ == "__main__":
    solution1_main()
    print("\n" + "#" * 72 + "\n")
    solution2_main()
    print("\n" + "#" * 72 + "\n")
    solution3_main()
