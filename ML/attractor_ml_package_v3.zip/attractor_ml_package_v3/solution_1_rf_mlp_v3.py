"""Solution 1: compare Random Forest and MLP on the shared project dataset."""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from shared_dataset import FEATURE_NAMES, generate_projects

OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


def build_models() -> dict[str, Pipeline]:
    return {
        "random_forest": Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                ("pca", PCA(n_components=2, random_state=42)),
                (
                    "classifier",
                    RandomForestClassifier(
                        n_estimators=300,
                        max_depth=6,
                        min_samples_leaf=3,
                        random_state=42,
                    ),
                ),
            ]
        ),
        "mlp": Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                ("pca", PCA(n_components=2, random_state=42)),
                (
                    "classifier",
                    MLPClassifier(
                        hidden_layer_sizes=(24, 12),
                        activation="relu",
                        alpha=1e-3,
                        learning_rate_init=0.01,
                        max_iter=2000,
                        random_state=42,
                    ),
                ),
            ]
        ),
    }


def save_rf_mlp_plot(result_df: pd.DataFrame, filepath: Path) -> None:
    plt.figure(figsize=(8, 6))
    scatter = plt.scatter(
        result_df["rf_probability"],
        result_df["mlp_probability"],
        c=result_df["true_label"],
        alpha=0.75,
    )
    plt.xlabel("Random Forest probability")
    plt.ylabel("MLP probability")
    plt.title("RF vs MLP on shared test set")
    plt.colorbar(scatter, label="True label")
    plt.tight_layout()
    plt.savefig(filepath, dpi=160)
    plt.close()


def main() -> None:
    dataset = generate_projects(n_samples=220, seed=42)
    df = dataset.frame

    X = df[FEATURE_NAMES]
    y = df["class_label"]

    X_train, X_test, y_train, y_test, train_index, test_index = train_test_split(
        X, y, df.index, test_size=0.28, random_state=42, stratify=y
    )

    models = build_models()
    probability_frames = []
    metric_rows = []

    for model_name, pipeline in models.items():
        pipeline.fit(X_train, y_train)
        y_pred = pipeline.predict(X_test)
        y_proba = pipeline.predict_proba(X_test)[:, 1]
        auc = roc_auc_score(y_test, y_proba)
        metric_rows.append(
            {
                "model": model_name,
                "roc_auc": auc,
                "confusion_matrix": str(confusion_matrix(y_test, y_pred).tolist()),
                "classification_report": classification_report(y_test, y_pred, digits=4),
            }
        )
        probability_frames.append(
            pd.DataFrame(
                {
                    "project_name": df.loc[test_index, "project_name"].values,
                    "true_label": y_test.values,
                    f"{model_name}_predicted_label": y_pred,
                    f"{model_name}_probability": y_proba,
                }
            )
        )

    result_df = probability_frames[0]
    for frame in probability_frames[1:]:
        result_df = result_df.merge(frame, on=["project_name", "true_label"], how="inner")

    result_df = result_df.rename(columns={
        "random_forest_probability": "rf_probability",
        "random_forest_predicted_label": "rf_predicted_label",
    })
    result_df = result_df.sort_values(by=["rf_probability", "mlp_probability"], ascending=False)
    metrics_df = pd.DataFrame(metric_rows)

    save_rf_mlp_plot(result_df, OUTPUT_DIR / "solution_1_v3_rf_mlp_plot.png")
    result_df.to_csv(OUTPUT_DIR / "solution_1_v3_predictions.csv", index=False)
    metrics_df.to_csv(OUTPUT_DIR / "solution_1_v3_metrics.csv", index=False)

    print("=" * 72)
    print("SOLUTION 1 V3 | RANDOM FOREST + MLP")
    print("=" * 72)
    print(metrics_df[["model", "roc_auc"]].to_string(index=False))
    print("\nTop 10 test predictions")
    print(result_df.head(10).to_string(index=False))


if __name__ == "__main__":
    main()
