"""Solution 2: weighted attractor with static and dynamic rankings."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from shared_dataset import FEATURE_NAMES, IDEAL_VECTOR, generate_projects

OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


@dataclass
class ResonantAttractor:
    target_vector: np.ndarray
    feature_names: list[str]
    weights: np.ndarray

    def weighted_distance(self, vector: np.ndarray) -> float:
        diff = vector - self.target_vector
        return float(np.sqrt(np.sum(self.weights * np.square(diff))))

    def resonance(self, vector: np.ndarray) -> float:
        return 1.0 / (1.0 + self.weighted_distance(vector))

    def explain(self, vector: np.ndarray) -> dict[str, float]:
        contributions = self.weights * np.square(vector - self.target_vector)
        return {name: float(value) for name, value in zip(self.feature_names, contributions)}

    def rank(self, frame: pd.DataFrame) -> pd.DataFrame:
        ranked = frame.copy()
        ranked["resonance"] = ranked[self.feature_names].apply(
            lambda row: self.resonance(row.to_numpy(dtype=float)), axis=1
        )
        ranked["weighted_distance"] = ranked[self.feature_names].apply(
            lambda row: self.weighted_distance(row.to_numpy(dtype=float)), axis=1
        )
        return ranked.sort_values(by="resonance", ascending=False)

    def update_from_top_k(self, frame: pd.DataFrame, top_k: int = 10, alpha: float = 0.60) -> np.ndarray:
        ranked = self.rank(frame).head(top_k)
        mean_top = ranked[self.feature_names].mean().to_numpy(dtype=float)
        self.target_vector = alpha * self.target_vector + (1.0 - alpha) * mean_top
        return self.target_vector.copy()


def main() -> None:
    dataset = generate_projects(n_samples=220, seed=42)
    df = dataset.frame

    weights = np.array([1.20, 1.00, 1.10, 1.55, 1.45], dtype=float)
    attractor = ResonantAttractor(
        target_vector=IDEAL_VECTOR.copy(),
        feature_names=FEATURE_NAMES.copy(),
        weights=weights,
    )

    ranked_static = attractor.rank(df)
    best_project = ranked_static.iloc[0]
    explanation = pd.DataFrame(
        [{"feature": k, "contribution": v} for k, v in attractor.explain(best_project[FEATURE_NAMES].to_numpy(dtype=float)).items()]
    ).sort_values(by="contribution", ascending=False)

    old_target = attractor.target_vector.copy()
    new_target = attractor.update_from_top_k(df, top_k=10, alpha=0.60)
    ranked_dynamic = attractor.rank(df)

    comparison = ranked_dynamic[["project_name", "resonance"]].rename(columns={"resonance": "dynamic_resonance"}).merge(
        ranked_static[["project_name", "resonance"]].rename(columns={"resonance": "static_resonance"}),
        on="project_name",
        how="left",
    )
    comparison["resonance_shift"] = comparison["dynamic_resonance"] - comparison["static_resonance"]

    pd.DataFrame(
        {
            "feature": FEATURE_NAMES,
            "old_target": old_target,
            "new_target": new_target,
            "delta": new_target - old_target,
        }
    ).to_csv(OUTPUT_DIR / "solution_2_v3_target_shift.csv", index=False)
    ranked_static.to_csv(OUTPUT_DIR / "solution_2_v3_static_ranking.csv", index=False)
    ranked_dynamic.to_csv(OUTPUT_DIR / "solution_2_v3_dynamic_ranking.csv", index=False)
    comparison.to_csv(OUTPUT_DIR / "solution_2_v3_comparison.csv", index=False)
    explanation.to_csv(OUTPUT_DIR / "solution_2_v3_best_project_explanation.csv", index=False)

    print("=" * 72)
    print("SOLUTION 2 V3 | RESONANT ATTRACTOR")
    print("=" * 72)
    print("Top 10 static ranking")
    print(ranked_static[["project_name", "resonance", "weighted_distance"]].head(10).to_string(index=False))
    print("\nUpdated target vector")
    print(np.round(new_target, 4))


if __name__ == "__main__":
    main()
