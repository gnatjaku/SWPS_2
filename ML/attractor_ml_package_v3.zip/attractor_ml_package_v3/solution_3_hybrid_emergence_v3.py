"""Solution 3: hybrid decision layer and emergence analysis."""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from shared_dataset import FEATURE_NAMES, IDEAL_VECTOR, generate_projects
from solution_2_resonant_attractor_v3 import ResonantAttractor

OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


def minmax(series: pd.Series) -> pd.Series:
    denom = series.max() - series.min()
    if denom == 0:
        return pd.Series(np.zeros(len(series)), index=series.index)
    return (series - series.min()) / denom


def rank_from_scores(df: pd.DataFrame, score_column: str) -> pd.DataFrame:
    ranked = df[["project_name", score_column]].copy()
    ranked = ranked.sort_values(by=score_column, ascending=False).reset_index(drop=True)
    ranked["rank"] = np.arange(1, len(ranked) + 1)
    return ranked


def top_k_overlap(a: pd.DataFrame, b: pd.DataFrame, k: int = 10) -> int:
    set_a = set(a.head(k)["project_name"])
    set_b = set(b.head(k)["project_name"])
    return len(set_a & set_b)


def save_hybrid_plot(frame: pd.DataFrame, filepath: Path) -> None:
    plt.figure(figsize=(8, 6))
    scatter = plt.scatter(
        frame["ensemble_probability"],
        frame["resonance"],
        c=frame["hybrid_score"],
        alpha=0.8,
    )
    plt.xlabel("Ensemble probability")
    plt.ylabel("Attractor resonance")
    plt.title("Hybrid decision map")
    plt.colorbar(scatter, label="Hybrid score")
    plt.tight_layout()
    plt.savefig(filepath, dpi=160)
    plt.close()


def build_models() -> dict[str, Pipeline]:
    return {
        "random_forest": Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                ("pca", PCA(n_components=2, random_state=42)),
                (
                    "classifier",
                    RandomForestClassifier(
                        n_estimators=300,
                        max_depth=6,
                        min_samples_leaf=3,
                        random_state=42,
                    ),
                ),
            ]
        ),
        "mlp": Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                ("pca", PCA(n_components=2, random_state=42)),
                (
                    "classifier",
                    MLPClassifier(
                        hidden_layer_sizes=(24, 12),
                        activation="relu",
                        alpha=1e-3,
                        learning_rate_init=0.01,
                        max_iter=2000,
                        random_state=42,
                    ),
                ),
            ]
        ),
    }


def main() -> None:
    dataset = generate_projects(n_samples=220, seed=42)
    df = dataset.frame
    X = df[FEATURE_NAMES]
    y = df["class_label"]

    X_train, X_test, y_train, y_test, train_index, test_index = train_test_split(
        X, y, df.index, test_size=0.28, random_state=42, stratify=y
    )

    models = build_models()
    probs: dict[str, np.ndarray] = {}
    metrics_rows = []
    for name, pipeline in models.items():
        pipeline.fit(X_train, y_train)
        proba = pipeline.predict_proba(X_test)[:, 1]
        probs[name] = proba
        metrics_rows.append({"model": name, "roc_auc": roc_auc_score(y_test, proba)})

    weights = np.array([1.20, 1.00, 1.10, 1.55, 1.45], dtype=float)
    attractor = ResonantAttractor(
        target_vector=IDEAL_VECTOR.copy(),
        feature_names=FEATURE_NAMES.copy(),
        weights=weights,
    )
    resonance_scores = X_test.apply(lambda row: attractor.resonance(row.to_numpy(dtype=float)), axis=1).to_numpy()

    hybrid_df = pd.DataFrame(
        {
            "project_name": df.loc[test_index, "project_name"].values,
            "true_label": y_test.values,
            "rf_probability": probs["random_forest"],
            "mlp_probability": probs["mlp"],
            "resonance": resonance_scores,
        }
    )
    hybrid_df["ensemble_probability"] = (hybrid_df["rf_probability"] + hybrid_df["mlp_probability"]) / 2.0
    hybrid_df["rf_scaled"] = minmax(hybrid_df["rf_probability"])
    hybrid_df["mlp_scaled"] = minmax(hybrid_df["mlp_probability"])
    hybrid_df["resonance_scaled"] = minmax(hybrid_df["resonance"])
    hybrid_df["hybrid_score"] = (
        0.35 * hybrid_df["rf_scaled"]
        + 0.35 * hybrid_df["mlp_scaled"]
        + 0.30 * hybrid_df["resonance_scaled"]
    )

    hybrid_df["decision_bucket"] = pd.cut(
        hybrid_df["hybrid_score"],
        bins=[-0.01, 0.40, 0.70, 1.01],
        labels=["reject", "review", "prioritize"],
    )
    hybrid_df = hybrid_df.sort_values(by="hybrid_score", ascending=False).reset_index(drop=True)

    rf_rank = rank_from_scores(hybrid_df, "rf_probability")
    mlp_rank = rank_from_scores(hybrid_df, "mlp_probability")
    resonance_rank = rank_from_scores(hybrid_df, "resonance")
    hybrid_rank = rank_from_scores(hybrid_df, "hybrid_score")

    emergence_summary = pd.DataFrame(
        [
            {"pair": "hybrid_vs_rf", "top10_overlap": top_k_overlap(hybrid_rank, rf_rank, 10), "spearman": hybrid_df[["hybrid_score", "rf_probability"]].corr(method="spearman").iloc[0, 1]},
            {"pair": "hybrid_vs_mlp", "top10_overlap": top_k_overlap(hybrid_rank, mlp_rank, 10), "spearman": hybrid_df[["hybrid_score", "mlp_probability"]].corr(method="spearman").iloc[0, 1]},
            {"pair": "hybrid_vs_resonance", "top10_overlap": top_k_overlap(hybrid_rank, resonance_rank, 10), "spearman": hybrid_df[["hybrid_score", "resonance"]].corr(method="spearman").iloc[0, 1]},
            {"pair": "rf_vs_mlp", "top10_overlap": top_k_overlap(rf_rank, mlp_rank, 10), "spearman": hybrid_df[["rf_probability", "mlp_probability"]].corr(method="spearman").iloc[0, 1]},
        ]
    )

    top10_union = set(rf_rank.head(10)["project_name"]) | set(mlp_rank.head(10)["project_name"]) | set(resonance_rank.head(10)["project_name"])
    emergent_top10 = hybrid_rank.head(10)
    emergent_cases = emergent_top10[~emergent_top10["project_name"].isin(top10_union)].copy()
    emergent_cases = emergent_cases.merge(hybrid_df, on="project_name", how="left")

    metrics_df = pd.DataFrame(metrics_rows)

    save_hybrid_plot(hybrid_df, OUTPUT_DIR / "solution_3_v3_hybrid_plot.png")
    hybrid_df.to_csv(OUTPUT_DIR / "solution_3_v3_hybrid_scores.csv", index=False)
    emergence_summary.to_csv(OUTPUT_DIR / "solution_3_v3_emergence_summary.csv", index=False)
    emergent_cases.to_csv(OUTPUT_DIR / "solution_3_v3_emergent_cases.csv", index=False)
    metrics_df.to_csv(OUTPUT_DIR / "solution_3_v3_ml_metrics.csv", index=False)
    hybrid_df.head(10).to_csv(OUTPUT_DIR / "solution_3_v3_top10.csv", index=False)

    print("=" * 72)
    print("SOLUTION 3 V3 | HYBRID + EMERGENCE")
    print("=" * 72)
    print(metrics_df.to_string(index=False))
    print("\nEmergence summary")
    print(emergence_summary.to_string(index=False))
    print("\nHybrid top 10")
    print(hybrid_df[["project_name", "hybrid_score", "decision_bucket"]].head(10).to_string(index=False))


if __name__ == "__main__":
    main()
