"""Shared synthetic dataset for RF/MLP/attractor/emergence demos."""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np
import pandas as pd

FEATURE_NAMES = [
    "novelty",
    "feasibility",
    "business",
    "vision_alignment",
    "depth",
]

IDEAL_VECTOR = np.array([0.90, 0.76, 0.84, 0.97, 0.94], dtype=float)

PROJECT_NAME_PREFIXES = [
    "Synapse", "Aether", "Quantum", "Atlas", "Helix", "Signal", "Cortex", "Vector"
]
PROJECT_NAME_SUFFIXES = [
    "Engine", "Layer", "Studio", "Forge", "Pilot", "Matrix", "Field", "Core"
]


@dataclass(frozen=True)
class ProjectDataset:
    frame: pd.DataFrame
    feature_names: List[str]


def _build_names(n_samples: int) -> List[str]:
    names: List[str] = []
    for i in range(n_samples):
        prefix = PROJECT_NAME_PREFIXES[i % len(PROJECT_NAME_PREFIXES)]
        suffix = PROJECT_NAME_SUFFIXES[(i * 3) % len(PROJECT_NAME_SUFFIXES)]
        names.append(f"{prefix} {suffix} {i + 1:03d}")
    return names


def generate_projects(n_samples: int = 220, seed: int = 42) -> ProjectDataset:
    rng = np.random.default_rng(seed)

    centers = np.array(
        [
            [0.90, 0.78, 0.85, 0.96, 0.92],
            [0.58, 0.92, 0.76, 0.52, 0.40],
            [0.96, 0.54, 0.90, 0.99, 0.98],
            [0.34, 0.64, 0.44, 0.26, 0.28],
            [0.72, 0.70, 0.62, 0.74, 0.70],
        ],
        dtype=float,
    )
    center_probs = np.array([0.27, 0.18, 0.17, 0.20, 0.18], dtype=float)

    rows = []
    names = _build_names(n_samples)
    for i in range(n_samples):
        center = centers[rng.choice(len(centers), p=center_probs)]
        noise = rng.normal(loc=0.0, scale=0.08, size=len(FEATURE_NAMES))
        vector = np.clip(center + noise, 0.0, 1.0)

        distance_to_ideal = float(np.linalg.norm(vector - IDEAL_VECTOR))
        quality_score = 1.0 / (1.0 + distance_to_ideal)
        class_label = int(
            quality_score > 0.69
            and vector[1] > 0.52
            and vector[2] > 0.58
            and vector[3] > 0.60
        )

        rows.append(
            {
                "project_name": names[i],
                **{feature: float(value) for feature, value in zip(FEATURE_NAMES, vector)},
                "quality_score": quality_score,
                "class_label": class_label,
            }
        )

    frame = pd.DataFrame(rows)
    return ProjectDataset(frame=frame, feature_names=FEATURE_NAMES.copy())
