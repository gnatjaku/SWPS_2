# Attractor ML Package v3

This package demonstrates a layered AI decision system built around four ideas:

1. Random Forest classification
2. MLP neural network classification
3. Resonant attractor ranking
4. Hybrid decision score with emergence analysis

## Files

- `shared_dataset.py` - synthetic project generator with five semantic dimensions
- `solution_1_rf_mlp_v3.py` - Random Forest vs MLP comparison
- `solution_2_resonant_attractor_v3.py` - static and dynamic attractor ranking
- `solution_3_hybrid_emergence_v3.py` - hybrid decision layer and emergence metrics
- `run_all.py` - launches the full demo
- `outputs/` - generated CSV and PNG artifacts

## Feature space

Each project is represented by:

- novelty
- feasibility
- business
- vision_alignment
- depth

## Educational idea

The package lets students compare three decision logics:

- **statistical prediction**: does the project belong to the positive class?
- **attractor proximity**: how close is the project to the desired vector of quality?
- **hybrid emergence**: what happens when RF, MLP, and attractor resonance create a combined layer?

## How to run

```bash
python run_all.py
```

or separately:

```bash
python solution_1_rf_mlp_v3.py
python solution_2_resonant_attractor_v3.py
python solution_3_hybrid_emergence_v3.py
```

## Produced artifacts

- `solution_1_v3_predictions.csv`
- `solution_1_v3_metrics.csv`
- `solution_1_v3_rf_mlp_plot.png`
- `solution_2_v3_static_ranking.csv`
- `solution_2_v3_dynamic_ranking.csv`
- `solution_2_v3_comparison.csv`
- `solution_2_v3_best_project_explanation.csv`
- `solution_2_v3_target_shift.csv`
- `solution_3_v3_hybrid_scores.csv`
- `solution_3_v3_emergence_summary.csv`
- `solution_3_v3_emergent_cases.csv`
- `solution_3_v3_ml_metrics.csv`
- `solution_3_v3_top10.csv`
- `solution_3_v3_hybrid_plot.png`

## What “emergence” means here

Emergence is treated operationally, not mystically.
The hybrid layer is considered emergent when its ranking is not merely a copy of RF, MLP, or attractor ranking.
The package measures that using:

- top-10 overlap
- Spearman correlation between score systems
- projects that enter hybrid top-10 without appearing in any base top-10 list
