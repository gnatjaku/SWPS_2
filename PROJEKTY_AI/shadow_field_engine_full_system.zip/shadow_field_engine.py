
from dataclasses import dataclass, field
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd

@dataclass
class Scenario:
    name: str
    description: str
    tags: List[str]
    values: Dict[str, float]

@dataclass
class Agent:
    name: str
    weights: Dict[str, float]
    bias: float = 0.0

    def evaluate(self, scenario: Scenario) -> float:
        score = self.bias
        for k, w in self.weights.items():
            score += scenario.values.get(k, 0.0) * w
        return float(np.clip(score, 0.0, 10.0))

class FieldMemory:
    def __init__(self):
        self.residue = {}

    def gravity(self, scenario: Scenario) -> float:
        return sum(self.residue.get(tag, 0.0) for tag in scenario.tags)

    def update(self, scenario: Scenario, strength=0.25):
        for tag in scenario.tags:
            self.residue[tag] = self.residue.get(tag, 0.0) + strength

class ShadowFieldEngine:
    def __init__(self, scenarios, agents, interference, memory=None):
        self.scenarios = scenarios
        self.agents = agents
        self.interference = interference
        self.memory = memory or FieldMemory()

    @staticmethod
    def softmax(x, temperature=1.0):
        x = np.array(x, dtype=float) / temperature
        e = np.exp(x - np.max(x))
        return e / e.sum()

    def agent_matrix(self):
        rows = []
        for s in self.scenarios:
            row = {"scenario": s.name}
            for a in self.agents:
                row[a.name] = a.evaluate(s)
            rows.append(row)
        return pd.DataFrame(rows)

    def field(self, temperature=1.0):
        rows = []
        for s in self.scenarios:
            scores = {a.name: a.evaluate(s) for a in self.agents}

            roi = scores["ROI_AGENT"]
            risk = scores["RISK_AGENT"]
            strategy = scores["STRATEGY_AGENT"]
            ethics = scores["ETHICS_AGENT"]
            data = scores["DATA_AGENT"]
            org = scores["ORG_AGENT"]

            tension_value_risk = abs(roi - risk)
            tension_ethics_strategy = abs(ethics - strategy)
            tension_data_org = abs(data - org)

            field_tension = (
                0.45 * tension_value_risk +
                0.30 * tension_ethics_strategy +
                0.25 * tension_data_org
            )

            semantic_gravity = self.memory.gravity(s)

            interference_score = 0.0
            for other in self.scenarios:
                if other.name == s.name:
                    continue
                interference_score += self.interference.get((s.name, other.name), 0.0)
                interference_score += 0.5 * self.interference.get((other.name, s.name), 0.0)

            energy = (
                0.30 * roi
                - 0.22 * risk
                + 0.24 * strategy
                + 0.12 * ethics
                + 0.10 * data
                + 0.08 * org
                - 0.18 * field_tension
                + 0.35 * semantic_gravity
                + 0.15 * interference_score
            )

            instability = field_tension + max(0, risk - ethics) + max(0, risk - org)

            rows.append({
                "scenario": s.name,
                "description": s.description,
                "tags": ", ".join(s.tags),
                "roi": roi,
                "risk": risk,
                "strategy": strategy,
                "ethics": ethics,
                "data": data,
                "organization": org,
                "field_tension": field_tension,
                "semantic_gravity": semantic_gravity,
                "interference": interference_score,
                "energy": energy,
                "instability": instability
            })

        df = pd.DataFrame(rows)
        df["probability"] = self.softmax(df["energy"].values, temperature=temperature)
        df["rank"] = df["probability"].rank(ascending=False, method="dense").astype(int)
        return df.sort_values("probability", ascending=False).reset_index(drop=True)

    def collapse(self, temperature=1.0):
        df = self.field(temperature=temperature)
        selected_row = df.iloc[0]
        selected = next(s for s in self.scenarios if s.name == selected_row["scenario"])
        self.memory.update(selected)
        shadows = df.iloc[1:4]
        return selected_row.to_dict(), shadows, df

    def timeline(self, rounds=5, temperature=1.0):
        rows = []
        for i in range(rounds):
            selected, shadows, df = self.collapse(temperature=temperature)
            rows.append({
                "round": i + 1,
                "selected": selected["scenario"],
                "probability": selected["probability"],
                "energy": selected["energy"],
                "field_tension": selected["field_tension"],
                "semantic_gravity": selected["semantic_gravity"]
            })
        return pd.DataFrame(rows)

def create_engine():
    scenarios = [
        Scenario("AI Knowledge Graph", "Warstwa wiedzy łącząca dokumenty, procedury i ekspertów.", ["knowledge", "stability", "data", "organization"], {"roi":7.0,"risk":3.5,"strategy":9.0,"ethics":8.0,"data":7.5,"organization":8.0}),
        Scenario("Predictive Maintenance", "Predykcja awarii, przestojów i planowanie utrzymania ruchu.", ["production", "prediction", "efficiency", "data"], {"roi":8.5,"risk":4.0,"strategy":8.0,"ethics":7.0,"data":8.0,"organization":6.5}),
        Scenario("AI Quality Control", "Wizja komputerowa i detekcja anomalii jakościowych.", ["production", "quality", "automation", "risk"], {"roi":8.0,"risk":5.5,"strategy":8.5,"ethics":6.5,"data":6.5,"organization":6.0}),
        Scenario("Customer Service Agent", "Agent obsługi klienta, reklamacji i historii kontaktu.", ["customer", "language", "automation", "reputation"], {"roi":6.5,"risk":5.0,"strategy":6.5,"ethics":6.0,"data":7.0,"organization":7.0}),
        Scenario("Financial Forecasting Agent", "Prognozy finansowe, cashflow i warianty scenariuszowe.", ["finance", "prediction", "strategy", "risk"], {"roi":7.5,"risk":6.5,"strategy":7.5,"ethics":6.0,"data":6.0,"organization":5.5}),
        Scenario("Autonomous Decision Cockpit", "Kokpit zarządczy z agentami, KPI i symulacją strategii.", ["strategy", "governance", "knowledge", "risk"], {"roi":9.0,"risk":8.0,"strategy":10.0,"ethics":6.5,"data":5.5,"organization":5.0}),
        Scenario("HR Competence Mapper", "Mapa kompetencji, luk i potrzeb szkoleniowych.", ["organization", "people", "ethics", "knowledge"], {"roi":5.5,"risk":4.5,"strategy":6.5,"ethics":7.0,"data":5.5,"organization":8.5}),
        Scenario("Logistics Optimization AI", "Optymalizacja tras, zapasów, magazynów i przepływu operacyjnego.", ["logistics", "efficiency", "prediction", "data"], {"roi":8.0,"risk":4.5,"strategy":7.5,"ethics":7.0,"data":7.0,"organization":6.5})
    ]

    agents = [
        Agent("ROI_AGENT", {"roi":1.0,"strategy":0.1,"risk":-0.1}),
        Agent("RISK_AGENT", {"risk":1.0,"ethics":-0.15,"organization":-0.1}, bias=0.5),
        Agent("STRATEGY_AGENT", {"strategy":1.0,"roi":0.1,"organization":0.1}),
        Agent("ETHICS_AGENT", {"ethics":1.0,"risk":-0.2,"organization":0.1}, bias=1.0),
        Agent("DATA_AGENT", {"data":1.0,"strategy":0.1,"risk":-0.05}),
        Agent("ORG_AGENT", {"organization":1.0,"ethics":0.15,"risk":-0.1})
    ]

    interference = {
        ("AI Knowledge Graph", "Customer Service Agent"): 1.4,
        ("AI Knowledge Graph", "HR Competence Mapper"): 1.0,
        ("AI Knowledge Graph", "Autonomous Decision Cockpit"): 1.8,
        ("Predictive Maintenance", "Logistics Optimization AI"): 1.5,
        ("Predictive Maintenance", "AI Quality Control"): 1.2,
        ("Financial Forecasting Agent", "Autonomous Decision Cockpit"): 1.1,
        ("Customer Service Agent", "AI Quality Control"): -0.4,
        ("Autonomous Decision Cockpit", "HR Competence Mapper"): -0.6
    }

    return ShadowFieldEngine(scenarios, agents, interference)

def report(selected, shadows):
    lines = []
    lines.append("SHADOW FIELD ENGINE — DECISION REPORT")
    lines.append("=" * 52)
    lines.append(f"COLLAPSED DECISION: {selected['scenario']}")
    lines.append(f"Probability: {selected['probability']:.3f}")
    lines.append(f"Energy: {selected['energy']:.3f}")
    lines.append(f"Field tension: {selected['field_tension']:.3f}")
    lines.append(f"Instability: {selected['instability']:.3f}")
    lines.append("")
    lines.append("SHADOW ALTERNATIVES:")
    for _, row in shadows.iterrows():
        lines.append(f"- {row['scenario']} | p={row['probability']:.3f}, energy={row['energy']:.3f}, tension={row['field_tension']:.3f}")
    lines.append("")
    lines.append("Core thesis: AI nie zwraca jednej odpowiedzi. AI buduje pole decyzji, mierzy napięcia i pozwala jednej konfiguracji się wyłonić.")
    return "\n".join(lines)
