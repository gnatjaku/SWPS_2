
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from shadow_field_engine import create_engine, report

engine = create_engine()

print("=== AGENT MATRIX ===")
print(engine.agent_matrix().round(2))

selected, shadows, field = engine.collapse(temperature=1.2)

print("\n=== DECISION FIELD ===")
print(field[["scenario","probability","energy","field_tension","semantic_gravity","interference","instability"]].round(3))

print("\n")
print(report(selected, shadows))

plt.figure(figsize=(10,6))
plt.scatter(field["field_tension"], field["energy"], s=field["probability"] * 2500 + 100, alpha=0.75)
for _, row in field.iterrows():
    plt.text(row["field_tension"] + 0.03, row["energy"] + 0.03, row["scenario"], fontsize=8)
plt.title("Shadow Field Map: Energy vs Field Tension")
plt.xlabel("Field tension")
plt.ylabel("Field energy")
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig("shadow_field_map.png", dpi=160)

timeline = engine.timeline(rounds=6, temperature=1.2)
print("\n=== TIMELINE WITH FIELD MEMORY ===")
print(timeline.round(3))

plt.figure(figsize=(10,5))
plt.plot(timeline["round"], timeline["energy"], marker="o")
plt.title("Decision Energy Across Collapses: Field Memory Effect")
plt.xlabel("Round")
plt.ylabel("Energy")
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig("field_memory_timeline.png", dpi=160)
