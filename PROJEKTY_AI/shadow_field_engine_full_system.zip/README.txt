
SHADOW FIELD ENGINE v0.3 — FULL SYSTEM

Zawartość:
1. shadow_field_engine.py
   Pełny silnik:
   - Scenario
   - Agent
   - FieldMemory
   - ShadowFieldEngine
   - FIELD TENSION DYNAMICS
   - semantic gravity
   - interference
   - probability field
   - collapse decision
   - timeline memory effect

2. shadow_field_engine_full_system.ipynb
   Notebook dydaktyczny na zajęcia.

3. demo_shadow_field_engine.py
   Skrypt demonstracyjny. Tworzy też:
   - shadow_field_map.png
   - field_memory_timeline.png

Wymagania:
pip install numpy pandas matplotlib nbformat

Teza:
To nie jest prosty scoring. To model pola decyzyjnego, w którym decyzja wyłania się z napięć, agentów,
interferencji i pamięci poprzednich stanów.
