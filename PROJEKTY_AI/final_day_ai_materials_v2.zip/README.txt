FINAL DAY AI MATERIALS

1. exercise_1_introspective_python.ipynb
   - Advanced Python introspection
   - AST transformation
   - Runtime self-modification
   - Reflective programming concepts

2. exercise_2_unusual_neural_networks.ipynb
   - Pure NumPy neural network used as semantic resonance detector
   - Non-classical interpretation of neural systems
   - Symbolic latent-space modeling
   - No TensorFlow required

3. exercise_3_shadow_field_engine.ipynb
   - Multi-agent decision field
   - FIELD TENSION DYNAMICS
   - Probabilistic collapse
   - Emergent AI decision architecture

4. final_day_ai_architectures.pptx
   - Short conceptual presentation for classroom use
