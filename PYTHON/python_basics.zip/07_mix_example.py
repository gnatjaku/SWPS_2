
"""
07_mix_example.py
Mały przykład łączący:
- typy i kolekcje,
- styl imperatywny,
- funkcje,
- prostą strukturę obiektową,
- i „rezonans” jako kryterium wyboru.
"""

from dataclasses import dataclass
from typing import List

@dataclass
class TrainingPlan:
    name: str
    weekly_km: int
    intensity: int  # 1–10
    hill_focus: int # 1–10

def score_for_tsm(plan: TrainingPlan) -> float:
    """
    Przykładowa funkcja oceny planu pod Tatra Sky Marathon:
    chcemy dużo km i dużo podbiegów (hill_focus), ale nie za wysoką intensywność.
    """
    return plan.weekly_km * 0.4 + plan.hill_focus * 0.5 - plan.intensity * 0.2

def main():
    plans: List[TrainingPlan] = [
        TrainingPlan("Lekki plan ogólny", weekly_km=40, intensity=4, hill_focus=3),
        TrainingPlan("Plan TSM – średni", weekly_km=60, intensity=6, hill_focus=7),
        TrainingPlan("Plan TSM – mocny", weekly_km=80, intensity=8, hill_focus=9),
    ]

    print("Dostępne plany:")
    for p in plans:
        print(p)

    print("\nOcena planów (im wyżej, tym lepiej pod TSM):")
    scores = [(p, score_for_tsm(p)) for p in plans]
    for p, s in scores:
        print(f"{p.name}: {s:.2f}")

    best = max(scores, key=lambda ps: ps[1])[0]
    print("\n>>> Najlepszy plan pod TSM wg tej funkcji:", best.name)

if __name__ == "__main__":
    main()
