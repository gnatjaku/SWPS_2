
"""
02_collections_basics.py
Podstawowe kolekcje: list, tuple, dict, set.
"""

def main():
    # Lista – uporządkowana, modyfikowalna
    numbers = [1, 2, 3, 4]
    numbers.append(5)
    print("numbers =", numbers)

    # Krotka (tuple) – uporządkowana, niemodyfikowalna
    coords = (10.0, 20.0)
    print("coords =", coords)

    # Słownik – mapowanie klucz -> wartość
    person = {
        "name": "Marcin",
        "age": 52,
        "city": "Lublin"
    }
    print("person =", person)

    # Zbiór – unikalne elementy, bez duplikatów
    tags = {"python", "ai", "python", "education"}
    print("tags =", tags)

    print("numbers =", numbers, type(numbers))
    print("coords =", coords, type(coords))
    print("person =", person, type(person))
    print("tags =", tags, type(tags))

    # Przykładowe operacje
    print("\nOperacje na kolekcjach:")
    print("numbers[0] =", numbers[0])
    print("coords[1] =", coords[1])
    print("person['name'] =", person['name'])
    print("'ai' in tags? ->", "ai" in tags)

if __name__ == "__main__":
    main()
