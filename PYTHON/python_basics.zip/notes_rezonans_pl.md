
# Notatki: styl imperatywny, funkcyjny, obiektowy i „rezonansowy”

## 1. Imperatywny

- Skupiony na krokach: „zrób to, potem to”.
- Zmieniamy stan programu (zmienne, kolekcje).
- Przykład: `03_control_flow_imperative.py`.

## 2. Funkcyjny

- Skupiony na transformacjach: „weź dane, przekształć, zwróć nową wartość”.
- Funkcje czyste, brak efektów ubocznych.
- Przykład: `04_functions_fp.py`.

## 3. Obiektowy

- Skupiony na bytach i ich zachowaniach.
- Klasy, obiekty, metody.
- Przykład: `05_oop_basics.py`.

## 4. Rezonansowy (wstępna wersja dydaktyczna)

Idea:

- Świat = zbiór opcji, scenariuszy, wektorów możliwości.
- Umysł / tożsamość = profil ważności cech, pola wartości.
- Kod = narzędzie mierzenia, która opcja NAJLEPIEJ „dzwoni” z tym profilem.

Wersja techniczna:

- Opcja ma słownik cech: `features: Dict[str, float]`.
- Profil ma wagi cech: `profile: Dict[str, float]`.
- Rezonans = suma (feature_value * waga_profilu) dla wspólnych cech.

To jest oczywiście bardzo uproszczony model. Kluczowe jest:

1. Zobaczyć, że można wyjść poza:
   - „liczenie BMI”
   - „średnią temperaturę”
2. Zrozumieć, że programowanie może modelować:
   - preferencje,
   - wartości,
   - pola decyzji.

Z tej idei można później iść w kierunku:
- rekomendacji,
- systemów decyzyjnych,
- wreszcie: dynamiczne polem znaczeń.
