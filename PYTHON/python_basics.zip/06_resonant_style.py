
"""
06_resonant_style.py
Wprowadzenie do „programowania rezonansowego” – wersja uproszczona dydaktycznie.

Pomysł:
- Mamy zestaw opcji (np. planów treningowych, źródeł wiedzy, decyzji biznesowych).
- Mamy profil preferencji (co jest dla nas ważne).
- Obliczamy „rezonans” = jak bardzo dana opcja pasuje do profilu.

To nie jest jeszcze pełna ANIMA/SynapseX, ale pokazuje studentom:
- że można myśleć o kodzie jako o narzędziu do mierzenia dopasowania
  między strukturą świata a wewnętrzną strukturą wartości.
"""

from dataclasses import dataclass
from typing import Dict, List

@dataclass
class Option:
    name: str
    features: Dict[str, float]  # cecha -> natężenie (0..1)

    @staticmethod
    def from_dict(d: Dict[str, float]) -> "Option":
        return Option(name=d["name"], features=d["features"])

    @classmethod
    def from_json(cls, s: str) -> "Option":
        import json
        return cls.from_dict(json.loads(s))

def resonance_score(option: Option, profile: Dict[str, float]) -> float:
    """
    Bardzo prosty model „rezonansu”:
    suma iloczynów feature * waga_profilu (tylko po wspólnych kluczach).
    """
    score = 0.0
    for key, weight in profile.items():
        value = option.features.get(key, 0.0)
        score += value * weight
    return score

def choose_best(options: List[Option], profile: Dict[str, float]) -> Option:
    # Wybieramy opcję o najwyższym „rezonansie” z profilem.
    return max(options, key=lambda opt: resonance_score(opt, profile))

def main():
    # Przykład: plany nauki Pythona
    options = [
        Option(
            name="Kurs: Podstawy Pythona",
            features={"praktyka": 0.6, "teoria": 0.4, "głębia": 0.3, "tempo": 0.5},
        ),
        Option(
            name="Kurs: Python dla Data Science",
            features={"praktyka": 0.8, "teoria": 0.5, "głębia": 0.7, "tempo": 0.6},
        ),
        Option(
            name="Kurs: Architektura i meta-programowanie",
            features={"praktyka": 0.5, "teoria": 0.8, "głębia": 0.9, "tempo": 0.4},
        ),
    ]

    # Profil studenta: co jest dla mnie ważne?
    profile = {
        "praktyka": 0.7,
        "teoria": 0.3,
        "głębia": 0.9,
        "tempo": 0.4,
    }

    print("=== Opcje ===")
    for opt in options:
        print("-", opt.name)

    print("\n=== Profil studenta (rezonansowy) ===")
    for k, v in profile.items():
        print(f"{k}: {v}")

    print("\n=== Wyniki rezonansu ===")
    for opt in options:
        s = resonance_score(opt, profile)
        print(f"{opt.name}: {s:.3f}")

    best = choose_best(options, profile)
    print("\n>>> Najwyższy rezonans ma:", best.name)

if __name__ == "__main__":
    main()
