
"""
04_functions_fp.py
Programowanie funkcyjne: funkcje czyste, map, filter, lambda, list comprehensions.
"""

from typing import List
import numpy as np
from book import booklist as bklist
from bk.book import bookstore,booklist as bknb

def square(x: int) -> int:
    # Funkcja czysta – dla tych samych argumentów zawsze ten sam wynik,
    # bez efektów ubocznych.
    return x * x

def is_even(x: int) -> bool:
    return x % 2 == 0

def main():
    numbers: List[int] = [1, 2, 3, 4, 5, 6]

    print("numbers =", numbers)

    # List comprehension – idiomatyczny Python
    squares = [square(n) for n in numbers]
    print("squares =", squares)

    # filter + map – bardziej „funkcyjnie”
    evens = list(filter(is_even, numbers))
    print("evens =", evens)

    doubled = list(map(lambda x: x * 2, numbers))
    print("doubled =", doubled)

    # Złożone przekształcenie – pipeline
    pipeline = [1, 2, 3, 4, 5, 6]
    result = [square(cc) for cc in pipeline if is_even(cc)]
    print("square(evens) =", result)

    print(f"lista książek: {bklist}")
    print(f"lista książek: {bknb}")
    print(f"lista księgarni: {bookstore}")

if __name__ == "__main__":
    main()
