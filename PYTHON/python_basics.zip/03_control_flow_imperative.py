
"""
03_control_flow_imperative.py
Instrukcje sterujące w stylu imperatywnym.
"""

def classify_bmi(bmi: float) -> str:
    if bmi < 18.5:
        return "niedowaga"
    elif bmi < 25:
        return "norma"
    elif bmi < 30:
        return "nadwaga"
    else:
        return "otyłość"

def main():
    weight = 90
    height = 1.72

    bmi = weight / (height ** 2)
    print("BMI =", round(bmi, 2))

    category = classify_bmi(bmi)
    print("Kategoria:", category)

    print("\nPętla for:")
    for i in range(5):
        print("i =", i)

    print("\nPętla while:")
    n = 3
    while n > 0:
        print("n =", n)
        n -= 1

if __name__ == "__main__":
    main()
