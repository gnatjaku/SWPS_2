
# Projekt: Wstęp do Pythona – typy, kolekcje, style programowania i podejście rezonansowe



## Struktura

- `01_types_basics.py` – podstawowe typy danych (int, float, bool, str, None)
- `02_collections_basics.py` – list, tuple, dict, set
- `03_control_flow_imperative.py` – sterowanie przepływem, styl imperatywny
- `04_functions_fp.py` – programowanie funkcyjne (funkcje czyste, map/filter, lambda)
- `05_oop_basics.py` – programowanie obiektowe (prosty model klasy)
- `06_resonant_style.py` – wprowadzenie do „stylu rezonansowego”
- `07_mix_example.py` – przykład łączący różne style
- `notes_rezonans_pl.md` – narracja do podejścia rezonansowego (dla wykładowcy)


