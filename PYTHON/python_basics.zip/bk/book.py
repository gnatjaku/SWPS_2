bookstore = ["Lublin","Warszawa","Poznań"]
booklist = [433455,869787,23123243,86787567,3234234,6565]