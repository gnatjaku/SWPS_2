
"""
05_oop_basics.py
Podstawy programowania obiektowego w Pythonie.
"""

class Runner:
    def __init__(self, name: str, weight: float):
        self.name = name
        self.weight = weight
        self.total_km = 0.0

    def run(self, km: float):
        self.total_km += km

    def info(self) -> str:
        return f"Runner({self.name}, weight={self.weight}, total_km={self.total_km})"

def main():
    r = Runner("Marcin", 89.0)
    r.run(10)
    r.run(21)
    r.run(44)

    print(r.info())

if __name__ == "__main__":
    main()
