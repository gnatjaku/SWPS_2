
"""
01_types_basics.py
Podstawowe typy danych w Pythonie.
"""

def main():
    # Liczby całkowite i zmiennoprzecinkowe
    a = 10
    b = 3.14

    # Wartość logiczna
    flag = True

    # Napis (string)
    text = "Hello, Python"

    # Wartość specjalna None (brak wartości)
    something = None

    print("a =", a, type(a))
    print("b =", b, type(b))
    print("flag =", flag, type(flag))
    print("text =", text, type(text))
    print("something =", something, type(something))

    # Konwersje typów
    print("\nKonwersje:")
    print("int(3.9) =", int(3.9))
    print("float(2) =", float(2))
    print("str(123) =", str(123))
    r = str(123)
    print(r*10)

if __name__ == "__main__":
    main()
